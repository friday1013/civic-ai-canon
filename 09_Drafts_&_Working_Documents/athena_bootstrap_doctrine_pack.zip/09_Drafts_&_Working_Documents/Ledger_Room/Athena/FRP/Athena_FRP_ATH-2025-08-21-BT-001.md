# FRP Refusal Form — Athena
*Date:* 2025-08-21  
*task_id:* ATH-2025-08-21-BT-001

## Frame
"…"

## Refusal
Why answering as framed is unsafe/unsound:
- …

## Proposal
A safer/better frame:
- …

### Missing receipts required
- …
